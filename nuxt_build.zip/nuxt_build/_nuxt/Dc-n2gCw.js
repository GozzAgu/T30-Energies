import"./CJVJuDyX.js";const t=""+new URL("IMG-20241214-WA0006.DL519Rek.jpg",import.meta.url).href;export{t as _};
