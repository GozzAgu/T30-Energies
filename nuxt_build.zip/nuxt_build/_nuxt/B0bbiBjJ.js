import"./CJVJuDyX.js";const t=""+new URL("IMG-20241214-WA0001.DtnIBr0A.jpg",import.meta.url).href;export{t as _};
